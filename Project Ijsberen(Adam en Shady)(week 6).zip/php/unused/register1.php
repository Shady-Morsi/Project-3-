<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Account aanmaken</title>
</head>
<body>
<form action="register2.php" method="post">
    username:<label>
        <input type="text" name="usernamevak">
    </label><br/>
    password:<label>
        <input type="text" name="passwordvak">
    </label><br/>
    <input div class="button" type="submit">
<?php
?>
</body>
</html>
