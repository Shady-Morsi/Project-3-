<?php

class Hint{

}
?>
